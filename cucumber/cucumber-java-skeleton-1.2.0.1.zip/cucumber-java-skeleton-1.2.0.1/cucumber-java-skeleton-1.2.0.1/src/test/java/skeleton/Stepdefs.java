package skeleton;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdefs {
	WebDriver driver;
	@Given("^open the brower and enter the url of testme application$")
	public void open_the_brower_and_enter_the_url_of_testme_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\WebDriver\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.get("http://localhost:8083/TestMeApp2.2/");
	    driver.findElement(By.partialLinkText("SignIn")).click();
	}

	@When("^user enters Lalitha as username$")
	public void user_enters_Lalitha_as_username() throws Throwable {
	    driver.findElement(By.name("userName")).sendKeys("Lalitha");
	    
	}

	@When("^user enters Password(\\d+) as password$")
	public void user_enters_Password_as_password(int arg1) throws Throwable {
		driver.findElement(By.name("password")).sendKeys("Password123");
	    
	}

	@When("^clicks on Login button$")
	public void clicks_on_Login_button() throws Throwable {
		driver.findElement(By.name("Login")).click();
	    
	}

	@Then("^login should be successful$")
	public void login_should_be_successful() throws Throwable {
	    Assert.assertEquals("Home", driver.getTitle());
	    
	}
}
