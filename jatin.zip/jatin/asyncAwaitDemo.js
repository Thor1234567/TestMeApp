async function test1() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("inside test1");
            resolve("test1");
        }, 3000)
    })
}

async function test2() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("inside test2");
            resolve("test2");
        }, 1000)
    })
}

async function awaitTest() {
   let response =  await test1();
   console.log(response);
    await test2();
    return 12;
}
awaitTest().then((result) => console.log(result));

