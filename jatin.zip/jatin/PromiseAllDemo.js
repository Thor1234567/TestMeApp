function myAsync(value){
    return new Promise((resolve, reject)=>{
        if(value>0)
        {
            resolve("value is positive") //success or fulfilled
        }
        else{
            error = new Error(" value shold be positive!");
            reject(error); //Rejected
        }
    });
}

function checkEven(value){
    return new Promise((resolve, reject)=>{
        if(value%2==0)
        {
            resolve("value is even") //success or fulfilled
        }
        else{
            error = new Error(" value should be even");
            reject(error); //Rejected
        }
    });
}

Promise.all([myAsync(0), checkEven(0)])
.then((result)=>{
    console.log(result);
})
.catch((err)=>{
    console.log("something went wrong")
})
.finally(()=>{
    console.log("finally");
})