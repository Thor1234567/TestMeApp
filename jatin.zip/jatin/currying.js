function volume(length){
    return function(width){
        return function(height){
            return length*width*height;
        }
    }
}

console.log(volume((2),(3),(4)));