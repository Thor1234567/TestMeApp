function myAsync(value){
    return new Promise((resolve, reject)=>{
        if(value>0)
        {
            resolve("value is positive") //success or fulfilled
            console.log("fulfilled!!");
        }
        else{
            error = new Error(" value shold be positive!");
            reject(error); //Rejected
        }
    });
}

function checkEven(value){
    return new Promise((resolve, reject)=>{
        if(value%2==0)
        {
            resolve("value is even") //success or fulfilled
            console.log("fulfilled!!");
        }
        else{
            error = new Error(" value should be even");
            reject(error); //Rejected
        }
    });
}

myValue = 10;
myAsync(myValue).then((result)=>{
    console.log(result);
    checkEven(myValue).then((result)=>{
        console.log(result);
    })
    .catch((err)=>{
        console.log("something went wrong::::"+err);
    });
    console.log("Do something...");
    console.log("Do something again...");
})
.catch((err)=>{
    console.log("something went wrong::::"+err);
});



