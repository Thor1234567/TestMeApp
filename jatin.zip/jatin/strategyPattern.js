
const AnimalSays = {
    dog()
    {
        return 'woof';
    },
    cat(){
        return 'meow';

    },
    lion(){
        return 'Roar';
    },
    default(){
        return 'moo';
    }
};

function makeAnimalSpeak(Animal){

    const speak = AnimalSays[Animal] || AnimalSays.default;
    console.log(Animal + "says::::" + speak());

}
makeAnimalSpeak('dog');
makeAnimalSpeak('cat');
makeAnimalSpeak('lion');
makeAnimalSpeak('snake');
