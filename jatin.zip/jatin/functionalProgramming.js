var books = [
    {name:'abc', pages: 100},
    {name:'xyz', pages:200}
];

//imperative
for(i=0;i<books.length;i++)
{
    books[i].lastRead = new Date();
}  

//declerative
books.map((book)=>{
    book.lastModified = new Date();
    return book;
})
console.log(books); 