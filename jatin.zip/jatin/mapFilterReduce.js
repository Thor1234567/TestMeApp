var books = [
    {name:'abc', type:'fiction', price: 100},
    {name:'xyz', type:'non-fiction', price:200},
    {name:'ddf', type:'fiction', price:500},
];

let fictionBooks = books.filter((book)=>{
    return book.type == "fiction";
})
console.log(fictionBooks);

let discountedPriceBooks = fictionBooks.map((book)=>{
    book.price = book.price/2;
    return book; 
})
console.log(discountedPriceBooks);

let totalCost = discountedPriceBooks.reduce((value, book)=>{
    return value + book.price;
},0);

console.log("total cost:::::"+totalCost);