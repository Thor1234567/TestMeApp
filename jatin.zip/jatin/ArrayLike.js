var array1 = ['a','b','c'];

var arrayLike = {
    0:'a',
    1:'b',
    2:'c',
    length:3
}
console.log(array1);
console.log(arrayLike);
console.log(arrayLike['0']);

//Function Arguments
function func(){
    console.log(arguments);
}



function func(arg){
    console.log('here');
}

function func(arg1, arg2){
    console.log('here with 2 args');
}

func(2);
func(4,5);

newArray = Array.from(arrayLike);
console.log(newArray);
