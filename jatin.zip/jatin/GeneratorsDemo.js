function* nums(i){
    console.log("starting generator...");
    yield i[0]*10;
    yield i[1]*3;
    console.log("after yield 2:::"+i[1]*3);
    yield i[2]/2;
    console.log("after yield 3:::"+i[2]*4);
    yield i[3];

}

val = [10,20,30, 40];
let generator = nums(val);//returning iterator
console.log(generator.next());
generator.next();
console.log(generator.next());
generator.next();
console.log(generator.next());
//generator.throw(nums);
generator.next();
console.log(generator.next());
generator.next();

