
//sum(11, 12);

//Function expressions
var add = function (a, b) {
    this.result = a + b; //this => window
    return this.result;

}
//add(10, 12);
//Function statements
function sum(a, b) {
    this.result = a + b; //this refers to function object
    return this.result;

}

//Arrow functions

plus = (a, b) => {

    return a + b;
}
console.log("Sum= " + sum(5, 127));
console.log("add= " + add(5, 147));
console.log(plus(5, 167));

//IIFE

let iffyResult = (function (a, b) {
    var result = a + b;
    return result;
})(1, 2);

console.log("...IIFE.." + iffyResult);

//******************* */function closures********************
//how to call inner functions

var country = "India";
var myCompany = function () {
    var companyName = 'Accenture';
    var myLocation = function (loc) {
        console.log("location:::" + loc + "::company:::" + companyName + ":::country:::" + country);
    }
    myLocation('ddc');
    return myLocation;
}
var company = myCompany();
company("bdc");

//example with multiple inner functions
var calculate = function (number) {
    // var result = number;
    var increment = function () {
        ++number;
        console.log("number::::::"+number);
        //result += increment;
        // console.log(result);
    }
    var decrement = function () {
        --number;
        console.log("number::::::"+number);
        
    }
     var multiply = function(z){
         console.log("after multiply:::"+number*z)
     }
    console.log("number::::::"+number);
   /* return {
        increment : increment,
        decrement : decrement
    }*/
    //object destructuring 
    return{increment, decrement, multiply}
    
}
var sum = calculate(50);
sum.increment();
sum.increment();
sum.increment();
sum.decrement();
sum.decrement();
sum.multiply(3); 

/*(function(){
    var a=4;
})();
console.log(a);*/ 

