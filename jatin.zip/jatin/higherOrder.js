/*const arr = [5, 7, 1, 8, 4];
let sum = 0;
for(let i = 0; i < arr.length; i++) {
  sum = sum + arr[i];
}
// prints 25
console.log(sum);*/

const arr = [5, 7, 1, 8, 4];
const sum = arr.reduce(function(accumulator, currentValue) {
  return accumulator + currentValue;
}, 10);
// prints 35
console.log(sum);

//custom higher order functions 

formatCurrency =  function(currencySymbol, DecimalSeparator){
    return function(value)
    {
        wholePart  = Math.trunc(value/100);
        fractionpart = value%100;
        return `${currencySymbol}${wholePart}${DecimalSeparator}${fractionpart}`
    }
}

getCurrency = formatCurrency('$', '.');
console.log(getCurrency(1000));